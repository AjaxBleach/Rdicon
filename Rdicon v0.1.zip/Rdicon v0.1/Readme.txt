Rdicon v0.1 - 1 Nov 2017
Author: Mario Alanzo Junior Mills

Description:
Gives removable storage (eg. USB) a random icon.

Instructions:
1.Bakup any existing Autorun.inf file.
2.Place files in usb (not in a folder).
3.Place your icons in the icon folder.
4.Run RdiconV0.1.bat to generate Autorun.inf.
5.Safely ejject and plug usb in and out of computer to see new icon.